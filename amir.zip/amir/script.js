const name_group = document.getElementById('name_group');
const date_time = document.getElementById('date_time');
const graduation = document.getElementById('graduation');
const first_number = document.getElementById('first_number');
const second_number = document.getElementById('second_number');
const multiply_btn = document.getElementById('multiply_btn');
const divide_btn = document.getElementById('divide_btn');
const result = document.getElementById('result');

// Task 1
name_group.innerText = "Amir Zhunusov CS 2112";

// Task 2
const current_date = new Date();
let full_date = "";
full_date += "Year: " + current_date.getFullYear() + "\n";
full_date += "Today is: " + current_date.toLocaleDateString('en-US', { weekday: 'long' }) + "\n";
full_date += "Date: " + current_date.getDate() + "\n";
full_date += "Month: " + (current_date.getMonth() + 1) + "\n";
full_date += "Current time is: " + ('0' + current_date.getHours()).slice(-2) + ":" + ('0' + current_date.getMinutes()).slice(-2) + ":" + ('0' + current_date.getSeconds()).slice(-2);
date_time.innerText = full_date;

// Task 3
const graduation_date = new Date("06/30/2024");
const days_left = (graduation_date.getTime() - current_date.getTime()) / (1000 * 60 * 60 * 24);
graduation.innerText = parseInt(days_left, 10) + " days left until the freedom!";

// Task 4
multiply_btn.onclick = function() {
    const first_number_value = parseInt(first_number.value, 10);
    const second_number_value = parseInt(second_number.value, 10);
    result.innerText = first_number_value * second_number_value;
};

divide_btn.onclick = function() {
    const first_number_value = parseInt(first_number.value, 10);
    const second_number_value = parseInt(second_number.value, 10);
    result.innerText = first_number_value / second_number_value;
};